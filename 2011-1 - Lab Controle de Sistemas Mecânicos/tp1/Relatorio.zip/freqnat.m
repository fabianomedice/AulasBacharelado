function [k]= freqnat(Ts,Epsilon)
k = 4/(Ts*Epsilon);
